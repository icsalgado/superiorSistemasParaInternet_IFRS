/*Escreva um algoritmo que escreva números de 1 a 10.
Usando o comando FOR (for(i=10;i>0;i--)) com decremento.
(use a imaginação).*/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main(){

    for(int i = 10; i >= 1; i--){
        printf("%d\n", 11-i);
    }

}